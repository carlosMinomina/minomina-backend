const mindee = require('mindee');

// Inicializa Mindee con la API Key desde entorno
mindee.init({ apiKey: process.env.MINDEE_API_KEY });

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método no permitido' });
  }

  try {
    const { pdfBase64 } = req.body;

    if (!pdfBase64) {
      return res.status(400).json({ error: 'Falta el PDF en base64' });
    }

    const pdfBuffer = Buffer.from(pdfBase64, 'base64');
    const inputSource = new mindee.PdfSource({ content: pdfBuffer });

    const prediction = await mindee.parse(
      mindee.Product.PayslipV4,
      inputSource
    );

    const doc = prediction.document;

    const analysis = {
      salarioBruto: doc.salary?.value || 'No detectado',
      salarioNeto: doc.netPay?.value || 'No detectado',
      irpf: doc.incomeTax?.value || 'No detectado',
      seguridadSocial: doc.socialSecurityEmployee?.value || 'No detectado',
      salarioBase: doc.salary?.value || 'No detectado',
      prorrataPagas: doc.proratedBonus?.value || 'No detectado',
      fecha: doc.date?.value || 'No detectado',
      empresa: doc.employer?.name || 'No detectada',
      empleado: doc.employee?.name || 'No detectado'
    };

    res.status(200).json({ analysis });
  } catch (error) {
    console.error('Error con Mindee:', error);
    res.status(500).json({ error: 'No se pudo analizar la nómina' });
  }
}